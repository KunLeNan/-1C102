// NodeThree
// 包含头文件，初始化系统及相关模块
#include "ls1x.h"
#include "Config.h"
#include "ls1x_gpio.h"
#include "ls1x_latimer.h"

#include "ls1c102_interrupt.h"
#include "iic.h"
#include "oled.h"
#include "dht11.h"
#include "BEEP.h"
#include "key.h"
#include "led.h"
#include "ls1c102_adc.h"
#include "queue.h"
#include "ZigBee.h"

#define LED 20
#define LED3_PIN GPIO_PIN_27
#define LED4_PIN GPIO_PIN_26


// 定义用于显示的字符串及数据变量
char str[50];
int value;
uint8_t received_data = 0;
int time = 0;
int FIRE, Smoke;

static uint16_t temperature;
static uint16_t humidity;

uint8_t data[8]; // 数据包

// 主函数
int main(int arg, char *args[])
{
    
    EnableInt(); // 开总中断

    // Queue_Init(&Circular_queue);
    BEEP_Init();
    
    // 初始化系统时钟、GPIO、OLED、中断、UART、ZigBee等模块
    SystemClockInit(); // 时钟等系统配置
    GPIOInit();        // io配置
    OLED_Init();
    EnableInt();        // 开总中断
    Uart1_init(9600);
    DL_LN3X_Init(DL_LN3X_NODE, CHANNEL, Network1_Id); // 设置为主机（接收端），设置信道为0x12，网络地址为0x0003
    Queue_Init(&Circular_queue);

    // 配置ADC相关引脚及初始化ADC
    AFIO_RemapConfig(AFIOB, GPIO_Pin_16, 0); // 初始化ADC通道6引脚
    Adc_powerOn();                           // 打开ADC电源
    Adc_open(ADC_CHANNEL_I6);                // 开启ADC通道6
    gpio_set_direction(GPIO_PIN_36, GPIO_Mode_In);
    gpio_set_direction(GPIO_PIN_34, GPIO_Mode_In);

    // OLED显示初始界面
   // OLED_Show_Str(5, 16, "No liquid ", 16); // OLED显示界面
    OLED_Show_Str(5, 6, "  ℃      %RH", 16);
    // 检测烟雾和火焰，并通过ZigBee发送数据
    while (1)
    {
        DHT11_Read_Data(&temperature, &humidity); // 读取温湿度值

        sprintf(str, "%2d", temperature / 10);     
        //OLED_Show_Str(70, 3, str, 16);           //显示温
        OLED_Show_Str(5, 6, str, 16);
        sprintf(str, "%2d", humidity / 10);
        //OLED_Show_Str(70, 6, str, 16);           //显示湿度
        OLED_Show_Str(70, 6, str, 16);
        delay_ms(500);



        // 检测是否有烟雾
        if (value = gpio_get_pin(GPIO_PIN_34))
        {
            OLED_Show_Str(5, 0, "No Smoke      ", 16);
            Smoke = 0;
            BEEP_OFF;
        }
        else
        {
            OLED_Show_Str(5, 0, "Smoke detected",16);
            Smoke = 1;
            BEEP_ON;
            delay_ms(500);
        }

        // 检测是否有火焰
        int FIRF = gpio_get_pin(GPIO_PIN_36);
        if (FIRF == 1)
        {
            OLED_Show_Str(5, 3, "No Flame      ", 16);
            FIRE = 0;
            BEEP_OFF;
            gpio_write_pin(GPIO_PIN_33, 0);
        }
        if (FIRF == 0)
        {
            OLED_Show_Str(5, 3, "Flaming        ", 16);
            FIRE = 1;
            BEEP_ON;
            gpio_write_pin(GPIO_PIN_33, 1);
        }

        // 组装数据包并发送
        data[0] = 0x04;
        data[1] = temperature / 256;
        data[2] = temperature % 256;
        data[3] = humidity / 256;
        data[4] = humidity % 256;
        data[5] = Smoke /256 ;
        data[6] = Smoke %256 ;
        data[7] = FIRE /256;
        data[8] = FIRE %256 ;


        delay_ms(444);
        DL_LN3X_Send(data, 9, ZIGBEE_RX_NODE);
    }

    return 0;
}